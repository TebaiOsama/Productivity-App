//
//  ViewControllerTaskPage.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 28/01/2021.
//

import UIKit

class ViewControllerTaskPage: UIViewController {

    var proj_select:proj? //the project that has been selected

    @IBOutlet weak var lbl_projName: UILabel!
    @IBOutlet weak var btn_icon: UIButton! //color icon
    @IBOutlet weak var TaskList: UITableView!
    @IBOutlet weak var btn_newTask: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        TaskList.register(UITableViewCell.self, forCellReuseIdentifier: "TaskItem")
        TaskList.delegate = self
        TaskList.dataSource = self
        
        
    
        lbl_projName!.text = proj_select?.name

        btn_icon.backgroundColor = proj_select?.colour
        btn_icon.layer.cornerRadius = 10
        btn_newTask.layer.cornerRadius = 15
        
    }
   
    @IBAction func addNewTask(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let destination = storyboard.instantiateViewController(identifier: "NewTask") as! ViewControllerNewTask
        destination.proj_select = proj_select

        navigationController?.pushViewController(destination, animated: true)
        
    }
    
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        
        let vc = unwindSegue.source as! ViewControllerNewTask
        
        proj_select?.taskList.append(Task(name: vc.tf_newTask.text!, duration: 0))
        
        TaskList.reloadData()
    }
    
}




//Interaction of cells
extension ViewControllerTaskPage: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}

extension ViewControllerTaskPage: UITableViewDataSource {
    //Returns rows number

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (proj_select?.taskList.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let TaskItem = tableView.dequeueReusableCell(withIdentifier: "TaskItem", for: indexPath)
        
        TaskItem.textLabel?.text = proj_select?.taskList[indexPath.row].name
        
        let btn_play = UIButton()
        btn_play.backgroundColor = UIColor.systemGreen
        let title = "▶ " + (proj_select?.taskList[indexPath.row].getDuration())!
        btn_play.titleLabel?.font =  .systemFont(ofSize: 15)
        btn_play.setTitle(title, for: .normal)
        btn_play.layer.cornerRadius = 5 //round buttons
        btn_play.frame.size = CGSize(width: 90, height: 20)
        TaskItem.accessoryView = btn_play
        
        return TaskItem
    }
}
