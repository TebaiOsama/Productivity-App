//
//  ViewControllerNewTask.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 28/01/2021.
//

import UIKit

class ViewControllerNewTask: UIViewController {

    var proj_select:proj?
    
    @IBOutlet weak var tf_newTask: UITextField!
    
    @IBOutlet weak var btn_save: UIBarButtonItem!
    
    @IBAction func isTextChanged(_ sender: Any) {
        if(tf_newTask.text != ""){
            btn_save.isEnabled = true
        }
        else{
            btn_save.isEnabled = false
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btn_save.isEnabled = false
       
    }
    


}
