//
//  ViewController4.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 28/01/2021.
//

import UIKit

class ViewController4: UITabBarController {
    
    var proj_select:proj? //the project that has been selected
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    

    

}
