//
//  ViewController2.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 07/01/2021.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var newProjPage: UIView!
    @IBOutlet weak var tf_newProject: UITextField!
    @IBOutlet weak var btn_save: UIBarButtonItem!

    @IBOutlet weak var btn_blue: UIButton!
    @IBOutlet weak var btn_red: UIButton!
    @IBOutlet weak var btn_yellow: UIButton!
    @IBOutlet weak var btn_green: UIButton!
    @IBOutlet weak var btn_black: UIButton!
    @IBOutlet weak var btn_indigo: UIButton!
    
    @IBOutlet weak var btn_icon: UIButton!
    
    @IBAction func isTextChanged(_ sender: Any) { //save button invisible if nothing is written on it
        if(tf_newProject.text != ""){
            btn_save.isEnabled = true
        }
        else{
            btn_save.isEnabled = false
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btn_save.isEnabled = false
        
        btn_blue.layer.cornerRadius = 15
        btn_red.layer.cornerRadius = 15
        btn_yellow.layer.cornerRadius = 15
        btn_green.layer.cornerRadius = 15
        btn_black.layer.cornerRadius = 15
        btn_indigo.layer.cornerRadius = 15
        btn_icon.layer.cornerRadius = 10
    }
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        btn_icon.backgroundColor = sender.backgroundColor
    }
    
    
}
