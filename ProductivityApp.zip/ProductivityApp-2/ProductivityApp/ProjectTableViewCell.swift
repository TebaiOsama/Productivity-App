//
//  ProjectTableViewCell.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 13/01/2021.
//

import UIKit

class ProjectTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
