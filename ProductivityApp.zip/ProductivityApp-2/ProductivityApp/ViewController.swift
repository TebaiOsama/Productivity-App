//
//  ViewController.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 07/01/2021.
//

import UIKit

//Single task
struct Task: Identifiable{
    var id = UUID()
    var name: String
    var duration: Int //Time frames in which the task was done
    
    mutating func getDuration() -> String{
        var result = String()
        let hours = Int(duration) / 3600
        let minutes = Int(duration) / 60 % 60
        let seconds = Int(duration) % 60
        result = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
        
        return result
    }}


//Single session
struct Session{
    var duration: Int
    var start: Date
    var end: Date
    var calendar: Calendar
    
    mutating func getHours() -> String{
        var result = String()
        let start_hour = calendar.component(.hour, from: start)
        let start_mins = calendar.component(.minute, from: start)
        let end_hour = calendar.component(.hour, from: end)
        let end_mins = calendar.component(.minute, from: end)
        result = String(format:"%02i:%02i - %02i:%02i",start_hour, start_mins, end_hour, end_mins)
        return result
    }
    
    mutating func getDuration() -> String{
        var result = String()
        let hours = Int(duration) / 3600
        let minutes = Int(duration) / 60 % 60
        let seconds = Int(duration) % 60
        result = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
        return result
        }
    }

//Single project
struct proj: Identifiable{
    var id = UUID()
    var name: String
    var sessions: [Session]
    var taskList: [Task]
    var colour: UIColor
}

//All of the projects
struct Project{
    static let shared = Project()
    public init() {}

    private(set) var projects: [proj] = []

    mutating func add(project: proj) {
        projects.append(project)
    }
    
    mutating func add(name: String, color: UIColor) {
        let temp = proj(name: name, sessions: [], taskList: [], colour: color)
        projects.append(temp)
    }
    
    func count() -> Int{
        return projects.count;
    }

    func getName() -> [String]{
        var nameList = [String]()
        for proj in projects{
            nameList.append(proj.name)
        }
        return nameList
    }
    
    mutating func setName(names: [String]){
        for i in 0..<names.count{
            add(name: names[i], color: UIColor.systemBlue)
        }
    }
    
    mutating func setProjects(projs: [proj]){
        projects = projs
    }
    
    func getColour() -> [UIColor]{
        var colourList = [UIColor]()
        for proj in projects{
            colourList.append(proj.colour)
        }
        return colourList
    }
    
    func getProj(i: Int) -> proj{
        return projects[i]
    }
}

var projectList = Project()

class ViewController: UIViewController {

    @IBOutlet weak var label_titlePage1: UILabel!
    @IBOutlet weak var btn_newProj: UIButton!
    @IBOutlet weak var ProjectList: UITableView!
    
    let defaults = UserDefaults.standard
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        btn_newProj.layer.cornerRadius = 10 //round buttons
        ProjectList.delegate = self
        ProjectList.dataSource = self
        
        
        defaults.set(["Studying Literature"], forKey: "ProjectNames")
        
        projectList.setName(names: defaults.object(forKey: "ProjectNames") as! [String])
    }
    
    //fct that get name and color of the new project, and adds it
    @IBAction func save(_ unwindSegue: UIStoryboardSegue) {
        
        let vc = unwindSegue.source as! ViewController2
        
        projectList.add(name: vc.tf_newProject.text!, color: vc.btn_icon.backgroundColor!)
        
        defaults.set(projectList.getName(), forKey: "ProjectNames")
        ProjectList.reloadData()
    }
}

//Interaction of cells
extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        

        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let destination = storyboard.instantiateViewController(identifier: "ProjectPage") as! ViewController3
     
        
        destination.proj_select = projectList.getProj(i: indexPath [1])
        
        navigationController?.pushViewController(destination, animated: true)
    }
}
extension ViewController: UITableViewDataSource {
    //Returns rows number
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return projectList.count()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let ProjectItem = tableView.dequeueReusableCell(withIdentifier: "ProjectItem", for: indexPath)
        ProjectItem.textLabel?.text = projectList.getName()[indexPath.row]
        //On a un texte, suivi d'un bouton de la couleur associée
        let btn_color = UIButton()
        btn_color.backgroundColor = projectList.getColour()[indexPath.row]
        btn_color.layer.cornerRadius = 5 //round buttons
        btn_color.frame.size = CGSize(width: 10, height: 10)
        ProjectItem.accessoryView = btn_color
        
        
        return ProjectItem
    }
}

