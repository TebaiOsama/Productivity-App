//
//  ViewController3.swift
//  ProductivityApp
//
//  Created by Osama Tebai on 19/01/2021.
//

import UIKit

class ViewController3: UIViewController {

    var proj_select:proj? //the project that has been selected
    
    @IBOutlet weak var lbl_projectName: UILabel! //name of selected proj
    @IBOutlet weak var btn_icon: UIButton! //color icon
    @IBOutlet weak var btn_play: UIButton! //button stop play
    @IBOutlet weak var btn_menu: UIBarButtonItem! //hamburger menu
    @IBOutlet weak var lbl_timer: UILabel! //timer label
    @IBOutlet weak var lbl_sub_timer: UILabel! //subtitles of the timer
    @IBOutlet weak var SessionList: UITableView! //list of all sessions
    
    @IBOutlet weak var view_menu: UIView! //white view
    @IBOutlet weak var view_sideConstraint: NSLayoutConstraint! //side constraint of the white view
    @IBOutlet weak var menu_topConstraint: NSLayoutConstraint! //top constraint
    
    var isMenuVisible = false
    
    
    @IBAction func tasksTapped(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let destination = storyboard.instantiateViewController(identifier: "TaskPage") as! ViewControllerTaskPage
        destination.proj_select = proj_select
        isMenuVisible = false
        view_sideConstraint.constant = 0
        navigationController?.pushViewController(destination, animated: true)
    }
    
    @IBAction func btnTapped(_ sender: Any) {
        if !isMenuVisible{
            isMenuVisible = true
            view_sideConstraint.constant = -150
        }
        else{
            isMenuVisible = false
            view_sideConstraint.constant = 0
        }
    }
    
    var counter = 0 //seconds passed
    var start = Date()
    var end = Date()
    var timer = Timer()
    var calendar = Calendar.current
    
    @IBOutlet weak var height_constraint_start: NSLayoutConstraint! //height constraint of the start button
    
    @IBAction func startTimer(_ sender: Any) {
        if (height_constraint_start.constant == 91){ //if we start
            height_constraint_start.constant = 200
            btn_play.setTitle("◻ Stop project", for: .normal)
            btn_play.backgroundColor = UIColor.systemRed
            lbl_timer.isHidden = false
            lbl_sub_timer.isHidden = false
            
            start = Date()
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(updateTimer), userInfo: nil, repeats: true)
        
        }
        else{ //if we stop
            height_constraint_start.constant = 91
            btn_play.setTitle("▶ Start project", for: .normal)
            btn_play.backgroundColor = UIColor.systemGreen
            lbl_timer.isHidden = true
            lbl_sub_timer.isHidden = true
            
            end = Date()
            
            proj_select?.sessions.append(Session(duration: counter, start: start, end: end, calendar: calendar))
            SessionList.reloadData()
            timer.invalidate()
            counter = 0
            lbl_timer.text = String(format:"%02i:%02i:%02i", 0, 0, 0)
        }
    }
    
    @objc func updateTimer() {
        counter = counter + 1
        let hours = Int(counter) / 3600
        let minutes = Int(counter) / 60 % 60
        let seconds = Int(counter) % 60
        lbl_timer.text = String(format:"%02i:%02i:%02i", hours, minutes, seconds)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        SessionList.register(UITableViewCell.self, forCellReuseIdentifier: "SessionItem")
        SessionList.delegate = self
        SessionList.dataSource = self
        lbl_timer.isHidden = true
        lbl_sub_timer.isHidden = true
        lbl_projectName.text = proj_select?.name
        btn_icon.backgroundColor = proj_select?.colour
        btn_icon.layer.cornerRadius = 10
        btn_play.layer.cornerRadius = 15
    }
    
}

//Interaction of cells
extension ViewController3: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
}

extension ViewController3: UITableViewDataSource {
    //Returns rows number

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (proj_select?.sessions.count)!
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //let SessionItem = tableView.dequeueReusableCell(withIdentifier: "SessionItem", for: indexPath)
        var SessionItem = tableView.dequeueReusableCell(withIdentifier: "SessionItem")
        if SessionItem == nil {
            SessionItem = UITableViewCell(style: .value1, reuseIdentifier: "SessionItem")
        }
        if SessionItem == nil || SessionItem?.detailTextLabel == nil {
            SessionItem = UITableViewCell(style: .value1, reuseIdentifier: "SessionItem")
        }
        SessionItem?.textLabel?.text = proj_select?.sessions[indexPath.row].getHours()
        
        SessionItem?.detailTextLabel?.text = proj_select?.sessions[indexPath.row].getDuration()
        
        return SessionItem!
    }
}
